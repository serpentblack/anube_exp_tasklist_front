import { Component, OnInit, inject } from '@angular/core';
import { UserServiceService } from '../services/user-service.service';

@Component({
  selector: 'app-user-list',
  standalone: true,
  imports: [],
  templateUrl: './user-list.component.html',
  styleUrl: './user-list.component.css'
})
export default class UserListComponent implements OnInit{
  private UserServiceService = inject(UserServiceService);

  users: any[] = [];

  ngOnInit(): void {
    this.UserServiceService.list()
    .subscribe((users: any)=>{
      console.log(users);
      this.users = users;
    })
  }
}
